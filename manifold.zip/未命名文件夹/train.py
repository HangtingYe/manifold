import torch
from torch.utils.data import TensorDataset, DataLoader
import torch.optim as optim
import torch.nn.functional as F
import torch.nn as nn
from data import load
from models import Model
import random
import numpy as np
from scipy.optimize import linear_sum_assignment
import json
import ipdb
import argparse
import pickle
import sklearn
import scipy
import gc
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from sklearn.decomposition import PCA
from scipy.linalg import svd
import importlib
import toml
import os
import copy
import ot

# torch.autograd.set_detect_anomaly(True)

# def build_data_loader(dataset, batch_size=128, shuffle=False):
def build_data_loader(dataset, batch_size=128, shuffle=False):
    data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)
    return data_loader

def get_loss_function(task_type):
    if task_type == 'regression': 
        loss_func = F.mse_loss
    elif task_type == 'binclass':
        loss_func = F.binary_cross_entropy_with_logits
    elif task_type == 'multiclass':
        loss_func = F.cross_entropy
    return loss_func

def print_params(model):
    for name, param in model.named_parameters():
        print(f"Parameter {name}, grad: {param.grad}")

def run_one_epoch(eid, model, data_loader, loss_func, model_type, config, args, optimizer=None):
   
    running_loss = 0.0

    inputs = []

    ot_distance = 100

    for bid, (X_n, X_c, y) in enumerate(data_loader):
        
        pred = model(X_n, X_c)

        inputs.append([X_n, X_c])

        if loss_func == F.cross_entropy:
            loss = loss_func(pred, y)
        else:
            loss = loss_func(pred, y.reshape(-1,1))

        # batch level
        if args.matching == 'True':
            batch_samples = X_n.shape[0]
            sample_indices = np.random.permutation(batch_samples)
            half_samples = batch_samples // 2
            a_indices = sample_indices[:half_samples]
            b_indices = sample_indices[half_samples:]
            hidden1 = model.encoder(X_n[a_indices], X_c[a_indices])
            hidden2 = model.encoder(X_n[b_indices], X_c[b_indices])
            if args.dist == 'l2':
                distance_matrix = torch.sqrt(((hidden1.reshape(hidden1.shape[0],1,hidden1.shape[1])-hidden2)**2).sum(dim=2) + 1e-3)
                max_value = torch.quantile(distance_matrix, 0.85)
                distance_matrix = torch.clamp(distance_matrix, min=1e-4, max=max_value.item())
            elif args.dist == 'l1':
                distance_matrix = ((hidden1.reshape(hidden1.shape[0],1,hidden1.shape[1])-hidden2).abs()).sum(dim=2)
            elif args.dist == 'cos':
                distance_matrix = torch.mm(hidden1, hidden2.T) / (torch.mm(torch.sqrt(torch.sum(hidden1**2,dim=1,keepdim=True)), torch.sqrt(torch.sum(hidden2**2,dim=1,keepdim=True)).T) + 1e-4)
                distance_matrix = 1 - distance_matrix
            a = torch.empty(1, hidden1.shape[0], dtype=torch.float, requires_grad=False).fill_(1/hidden1.shape[0]).cuda().squeeze()       
            b = torch.empty(1, hidden2.shape[0], dtype=torch.float, requires_grad=False).fill_(1/hidden2.shape[0]).cuda().squeeze()
            # ot_distance = ot.emd2(a, b, distance_matrix) * 0.1
            ot_distance = ot.sinkhorn2(a, b, distance_matrix, reg=0.1, numItermax = 50) * 0.1
            loss += ot_distance
        
        # sample level
        if args.alignment == 'True':
            hidden = model.encoder(X_n, X_c)
            selected_rows = np.random.choice(hidden.shape[0], int(hidden.shape[0] * 0.5), replace=False)

            distance = torch.mm(hidden[selected_rows], hidden[selected_rows].T) / (torch.mm(torch.sqrt(torch.sum(hidden[selected_rows]**2,dim=1,keepdim=True)), torch.sqrt(torch.sum(hidden[selected_rows]**2,dim=1,keepdim=True)).T) + 1e-4)
            distance = 1 - distance
            # distance = (hidden[selected_rows].reshape(hidden[selected_rows].shape[0],1,hidden[selected_rows].shape[1])-hidden[selected_rows]).abs().sum(dim=2)
            if loss_func == F.cross_entropy:
                label_similarity = (y.reshape(-1,1)[selected_rows] == y.reshape(-1,1)[selected_rows].T).float()
            else:
                y_min = min(y)
                y_max = max(y)
                # using Sturges equation select bins in manuscripts
                num_bin = 1 + int(np.log2(y.shape[0]))
                # num_bin = 5
                interval_width = (y_max - y_min) / num_bin
                y_assign = torch.max(torch.tensor(0).cuda(),torch.min(((y.reshape(-1,1)-y_min)/interval_width).long(),torch.tensor(num_bin-1).cuda()))
                label_similarity = (y_assign.reshape(-1,1)[selected_rows] == y_assign.reshape(-1,1)[selected_rows].T).float()
            
            # extract similar pairs
            positive_mask = label_similarity
            negative_mask = 1-positive_mask

            positive_loss = torch.sum(distance * positive_mask) / (torch.sum(distance)+1e-8)
            loss_alignment = positive_loss * 0.1
            loss += loss_alignment

        if args.noisy == 'True':
            X_n_ =copy.deepcopy(X_n)
            selected_rows = np.random.choice(X_n_.shape[0], int(X_n_.shape[0] * 0.1), replace=False)
            X_n_ = X_n_[selected_rows]
            X_c_ = X_c[selected_rows]
            corelation = []
            for i in range(X_n.shape[1]):
                correlation_matrix = torch.corrcoef(torch.stack([X_n[:,i], y]))
                corelation.append(correlation_matrix[0, 1])
            corelation = F.softmax(torch.tensor(corelation))
            max_mask = int(X_n_.shape[1]*0.2)
            mask_matrix = []

            for i in range (X_n_.shape[0]):
                mask_count = 0
                mask_vector = torch.zeros(X_n_.shape[1])
                for j in range(X_n_.shape[1]):
                    value = torch.bernoulli(corelation[j])
                    if value == 1:
                        mask_vector[j] = 1
                        mask_count += 1
                    if mask_count == max_mask:
                        break
                mask_matrix.append(torch.tensor(mask_vector).reshape(1,-1).cuda())
            mask_matrix = torch.cat(mask_matrix, dim=0)
            std=0.5
            mean=0.0
            noise = torch.randn(X_n_.shape[0], X_n_.shape[1]) * std + mean
            noise = noise.cuda()
            X_n_tilde = X_n_ * (1-mask_matrix) + mask_matrix * noise

            hidden = model.encoder(X_n_, X_c_)
            hidden_ = model.encoder(X_n_tilde, X_c_)
            loss_noisy = F.mse_loss(hidden, hidden_)*0.1

            loss += loss_noisy

        running_loss += loss.item()

        if optimizer is not None:
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

    return running_loss / len(data_loader)


def fit(model, train_loader, val_loader, loss_func, model_type, config, task_type, y_std, args):
    best_val_loss = 1e30
    best_model = None

    optimizer = optim.AdamW(model.parameters(), lr=config['training']['lr'], weight_decay=config['training']['weight_decay'])

    early_stop = config['training']['patience']
    epochs = config['training']['n_epochs']

    patience = early_stop

    for eid in range(epochs):
        model.train()
        train_loss = run_one_epoch(
            eid, model, train_loader, loss_func, model_type, config, args, optimizer
        )

        model.eval()
        val_loss = run_one_epoch(
            eid, model, val_loader, loss_func, model_type, config, args
        )

        print(f'Epoch {eid}, train loss {train_loss}, val loss {val_loss}')

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_model = copy.deepcopy(model)
            # best_model = model
            patience = early_stop
        else:
            patience = patience - 1

        if patience == 0:
            break
    return best_model

def test(model, test_loader, task_type, y_std, args, config):

    model.eval()

    pred = []
    ground = []
    for bid, (X_n, X_c, y) in enumerate(test_loader):
        pred.append(model(X_n, X_c).data.cpu().numpy())
        ground.append(y)
    pred = np.concatenate(pred, axis=0)
    y = torch.cat(ground, dim=0)
    
    y = y.data.cpu().numpy()

    if task_type == 'binclass':
        pred = np.round(scipy.special.expit(pred))
        score = sklearn.metrics.accuracy_score(y.reshape(-1,1), pred.reshape(-1,1))
    elif task_type == 'multiclass':
        pred = pred.argmax(1)
        score = sklearn.metrics.accuracy_score(y.reshape(-1,1), pred.reshape(-1,1))
    else:
        assert task_type == 'regression'
        score = sklearn.metrics.mean_squared_error(y.reshape(-1,1), pred.reshape(-1,1)) ** 0.5 * y_std

    print(f'test result, {score.item()}')

    np.save(open(f'./results/{args.dataname}_{args.model_type}_{args.hyper}_0_{args.matching}_{args.dist}_{args.alignment}_{args.noisy}.npy','wb'), score.item())
    torch.save(model.state_dict(), f'./models/{args.dataname}_{args.model_type}_{args.hyper}_0_{args.matching}_{args.dist}_{args.alignment}_{args.noisy}.pth')

    

def _set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic = True
    os.environ['PYTHONHASHSEED'] = str(seed)


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--model_type', type=str)
    parser.add_argument('--dataname', type=str)
    parser.add_argument('--ratio', type=float, default=1.0)
    parser.add_argument('--hyper', type=str, default='default')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--matching', type=str)
    parser.add_argument('--dist', type=str, default='cos')
    parser.add_argument('--alignment', type=str)
    parser.add_argument('--noisy', type=str)
    args = parser.parse_args()

    _set_seed(args.seed)

    config = toml.load(f'./hypers_{args.hyper}/{args.dataname}/{args.model_type}.toml')

    with open(f'./data/{args.dataname}/info.json') as f:
        info = json.load(f)

    gc.collect()
    torch.cuda.empty_cache()

    # X['train']: (bs, cols)
    X, y, n_classes, y_mean, y_std, categories = load(args.dataname, info, config['data']['normalization'], args.ratio)
 
    task_type = info.get('task_type')
    print(task_type)

    n_num_features, n_cat_features = info.get('n_num_features'), info.get('n_cat_features')

    train_loader = build_data_loader(TensorDataset(X['train'][:,:n_num_features], X['train'][:,n_num_features:] if n_cat_features>0 else torch.empty(X['train'].shape[0], X['train'].shape[1]).cuda(), y['train']), config['training']['batch_size'], False)
    val_loader = build_data_loader(TensorDataset(X['val'][:,:n_num_features], X['val'][:, n_num_features:] if n_cat_features>0 else torch.empty(X['val'].shape[0], X['val'].shape[1]).cuda(), y['val']), config['training']['batch_size'], False)
    test_loader = build_data_loader(TensorDataset(X['test'][:, :n_num_features], X['test'][:, n_num_features:] if n_cat_features>0 else torch.empty(X['test'].shape[0], X['test'].shape[1]).cuda(), y['test']), config['training']['batch_size'], False)

    loss_func = get_loss_function(task_type)
    
    # X['train']: (bs, cols)
    model = Model(n_num_features, args.model_type, n_classes if task_type == 'multiclass' else 1, 
    info=info, config = config, categories = categories)
    model.cuda()

    best_model = fit(model, train_loader, val_loader, loss_func, args.model_type, config, task_type, y_std, args)
    # model.load_state_dict(torch.load(f'./results/{dataname}_{em_type}_{model_type}_{num}_model.pth'))

    test(best_model, test_loader, task_type, y_std, args, config)




